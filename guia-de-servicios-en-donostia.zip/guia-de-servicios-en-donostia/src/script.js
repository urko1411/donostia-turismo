// Función para abrir enlaces en una nueva pestaña y mostrar un mensaje
document.addEventListener('DOMContentLoaded', () => {
    const externalLinks = document.querySelectorAll('a[target="_blank"]');

    externalLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault(); // Previene el comportamiento por defecto
            const url = link.href;

            // Muestra un aviso
            alert('Este enlace se abrirá en una nueva pestaña.');
            
            // Abre el enlace en una nueva pestaña
            window.open(url, '_blank');
        });
    });
});
